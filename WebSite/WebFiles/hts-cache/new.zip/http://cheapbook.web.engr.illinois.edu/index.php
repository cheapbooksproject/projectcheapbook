<html>
<head>
<title>Sign In</title>
</head>
<body background="purpl1.gif">
<form action="index.php" method=get>
<div align="center">
<h1><b>Welcome to CheapBook. </b></h1>
</div>
<table border='2'><tr><td>username</td><td><input type='text' name='userlogin' size'20'></td></tr><tr><td>password</td><td><input type='password' name='password' size'20'></td></tr></table><input type='submit' value = 'Sign In'><h3><a href='registerform.php'>Don't have an account? Sign Up!</a></h3><h4><a href='administrator.html'>Having Issues? Contact Admin</a></h4><h4><a href='index.html'> Back to Home Page </a></h4>
</form>


</body>
</html>