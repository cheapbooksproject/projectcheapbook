<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>register</title>
</head>
<body background="purpl1.gif">
<FORM ACTION="register.php" METHOD=get>
<div align="center">
<h1><b>Welcome to CheapBook. </b></h1>
</div>
Please create your user credentials here<br>
<table border="2">
<tr>
<td>User Name :</td><td><input name="username" type="text" size"20"></input></td>
</tr>
<tr>
<td>UIUC email :</td><td><input name="useremail" type="text" size"20"></input></td>
</tr>
<tr>
<td>password :</td><td><input name="userpass1" type="password" size"20"></input></td>
</tr>
<tr>
<td>retype password :</td><td><input name="userpass2" type="password" size"20"></input></td>
</tr>
</table>
 <input type="submit" value="Sign Up!"></input>
</FORM>

<a href="index.html"> Back to Home Page </a>


</body>
</html>